#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V6 Hybrid
1) Stage1 ResNet34 U-Net: 전체 이미지에서 압흔 위치 탐색
2) Stage2 ResNet34 U-Net: ROI 확대 후 정밀 segmentation
3) V3 line-fitting geometry로 중심/대각선 방향 결정
4) 그 방향을 고정한 채 원본 Scharr edge + Stage2 mask 경계로 꼭짓점 snap
"""

from __future__ import annotations

import os
from pathlib import Path

import cv2
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision.models import ResNet34_Weights, resnet34

Vertex = tuple[float, float]
CORNERS = ("N", "E", "S", "W")
ARCH = "v6_1_hybrid_resnet34_roi_maskray_subpixel"
DEFAULT_SIZE = 512
ROI_SCALE = 2.3


# ---------------------------------------------------------------------
# data
# ---------------------------------------------------------------------
def is_vicker_root(path: Path) -> bool:
    return (
        (path / "DB-I").is_dir()
        and (path / "exact-masks-I").is_dir()
        and (path / "DB-II").is_dir()
        and (path / "exact-masks-II").is_dir()
    )


def find_data_root(explicit: Path | None = None) -> Path:
    def check(path: Path) -> Path | None:
        try:
            path = path.expanduser().resolve()
        except OSError:
            return None
        if is_vicker_root(path):
            return path
        nested = path / "Vicker_Database"
        if is_vicker_root(nested):
            return nested
        return None

    if explicit is not None:
        found = check(Path(explicit))
        if found is not None:
            return found
        raise FileNotFoundError(f"Vicker_Database를 찾지 못했습니다: {explicit}")

    kaggle = Path("/kaggle/input")
    if kaggle.exists():
        for p in kaggle.rglob("Vicker_Database"):
            found = check(p)
            if found:
                return found
        for p in kaggle.rglob("exact-masks-I"):
            found = check(p.parent)
            if found:
                return found

    here = Path(__file__).resolve().parent if "__file__" in globals() else Path.cwd()
    candidates = [
        here / "Vicker_Database",
        here.parent / "Vicker_Database",
        Path.cwd() / "Vicker_Database",
    ]
    env = os.environ.get("VICKER_DATABASE")
    if env:
        candidates.insert(0, Path(env))

    for p in candidates:
        found = check(p)
        if found:
            return found

    raise FileNotFoundError("Vicker_Database를 찾지 못했습니다.")


def db_dirs(root: Path, db: str) -> tuple[Path, Path]:
    tag = db.upper().replace("DB-", "")
    return root / f"DB-{tag}", root / f"exact-masks-{tag}"


def list_ids(root: Path, db: str) -> list[str]:
    img_dir, mask_dir = db_dirs(root, db)
    return [p.stem for p in sorted(img_dir.glob("*.png")) if (mask_dir / p.name).exists()]


def split_70_30(ids: list[str], seed: int = 42) -> tuple[list[str], list[str]]:
    rng = np.random.RandomState(seed)
    x = list(ids)
    rng.shuffle(x)
    n = int(round(len(x) * 0.7))
    n = min(max(n, 1), len(x) - 1) if len(x) > 1 else len(x)
    return x[:n], x[n:]


def load_gray(path: Path) -> np.ndarray:
    img = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(path)
    return img


def load_mask(path: Path) -> np.ndarray:
    m = load_gray(path)
    return np.where(m > 127, 255, 0).astype(np.uint8)


def enhance_gray(gray: np.ndarray) -> np.ndarray:
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    return clahe.apply(gray)


# ---------------------------------------------------------------------
# ResNet34 U-Net
# ---------------------------------------------------------------------
class ConvBlock(nn.Module):
    def __init__(self, in_ch: int, out_ch: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_ch),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.block(x)


class UpBlock(nn.Module):
    def __init__(self, in_ch: int, skip_ch: int, out_ch: int) -> None:
        super().__init__()
        self.conv = ConvBlock(in_ch + skip_ch, out_ch)

    def forward(self, x: torch.Tensor, skip: torch.Tensor) -> torch.Tensor:
        x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
        return self.conv(torch.cat([x, skip], dim=1))


class ResNet34UNet(nn.Module):
    def __init__(self, pretrained: bool = False) -> None:
        super().__init__()
        weights = ResNet34_Weights.IMAGENET1K_V1 if pretrained else None
        try:
            enc = resnet34(weights=weights)
        except Exception as exc:
            print(f"[WARN] pretrained ResNet34 로드 실패: {exc}")
            enc = resnet34(weights=None)

        self.conv1 = enc.conv1
        self.bn1 = enc.bn1
        self.relu = enc.relu
        self.maxpool = enc.maxpool
        self.layer1 = enc.layer1
        self.layer2 = enc.layer2
        self.layer3 = enc.layer3
        self.layer4 = enc.layer4

        self.up4 = UpBlock(512, 256, 256)
        self.up3 = UpBlock(256, 128, 128)
        self.up2 = UpBlock(128, 64, 64)
        self.up1 = UpBlock(64, 64, 64)

        self.final_conv = nn.Sequential(
            ConvBlock(64, 32),
            nn.Conv2d(32, 1, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x0 = self.relu(self.bn1(self.conv1(x)))
        x1 = self.layer1(self.maxpool(x0))
        x2 = self.layer2(x1)
        x3 = self.layer3(x2)
        x4 = self.layer4(x3)

        d4 = self.up4(x4, x3)
        d3 = self.up3(d4, x2)
        d2 = self.up2(d3, x1)
        d1 = self.up1(d2, x0)

        out = F.interpolate(d1, scale_factor=2, mode="bilinear", align_corners=False)
        return self.final_conv(out)


def gray_to_tensor(gray: np.ndarray, size: int, device: torch.device) -> torch.Tensor:
    x = cv2.resize(enhance_gray(gray), (size, size), interpolation=cv2.INTER_AREA)
    x = x.astype(np.float32) / 255.0
    rgb = np.stack([x, x, x], axis=0)
    return torch.from_numpy(rgb).unsqueeze(0).to(device)


@torch.no_grad()
def predict_full(
    model: nn.Module,
    gray: np.ndarray,
    size: int,
    device: torch.device,
    threshold: float = 0.5,
) -> np.ndarray:
    h, w = gray.shape[:2]
    prob = torch.sigmoid(model(gray_to_tensor(gray, size, device)).float())[0, 0].cpu().numpy()
    prob = cv2.resize(prob, (w, h), interpolation=cv2.INTER_LINEAR)
    return (prob > threshold).astype(np.uint8) * 255


# ---------------------------------------------------------------------
# ROI
# ---------------------------------------------------------------------
def largest_bbox(mask: np.ndarray):
    b = (mask > 127).astype(np.uint8) * 255
    contours, _ = cv2.findContours(b, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return None
    cnt = max(contours, key=cv2.contourArea)
    if cv2.contourArea(cnt) < 10:
        return None
    return cv2.boundingRect(cnt)


def square_roi_from_bbox(
    bbox: tuple[int, int, int, int],
    h_img: int,
    w_img: int,
    scale: float = ROI_SCALE,
    min_side: int = 96,
) -> tuple[int, int, int, int]:
    x, y, w, h = bbox
    cx, cy = x + 0.5 * w, y + 0.5 * h
    side = int(round(max(max(w, h) * scale, min_side)))
    side = min(side, max(h_img, w_img))
    x1, y1 = int(round(cx - side / 2)), int(round(cy - side / 2))
    x2, y2 = x1 + side, y1 + side

    if x1 < 0:
        x2 -= x1
        x1 = 0
    if y1 < 0:
        y2 -= y1
        y1 = 0
    if x2 > w_img:
        x1 -= x2 - w_img
        x2 = w_img
    if y2 > h_img:
        y1 -= y2 - h_img
        y2 = h_img

    return max(0, x1), max(0, y1), min(w_img, x2), min(h_img, y2)


def gt_roi_from_mask(
    mask: np.ndarray,
    scale: float = ROI_SCALE,
    jitter: float = 0.0,
) -> tuple[int, int, int, int]:
    h, w = mask.shape[:2]
    bbox = largest_bbox(mask)
    if bbox is None:
        side = int(round(min(h, w) * 0.60))
        cx, cy = w // 2, h // 2
        return max(0, cx-side//2), max(0, cy-side//2), min(w, cx+side//2), min(h, cy+side//2)

    x, y, bw, bh = bbox
    cx, cy = x + 0.5*bw, y + 0.5*bh
    if jitter > 0:
        span = max(bw, bh)
        cx += float(np.random.uniform(-jitter, jitter) * span)
        cy += float(np.random.uniform(-jitter, jitter) * span)
        scale = scale * float(np.random.uniform(0.92, 1.08))

    fake = (
        int(round(cx - bw/2)),
        int(round(cy - bh/2)),
        bw,
        bh,
    )
    return square_roi_from_bbox(fake, h, w, scale=scale)


@torch.no_grad()
def predict_roi(
    stage1: nn.Module,
    stage2: nn.Module,
    gray: np.ndarray,
    size: int,
    device: torch.device,
    roi_scale: float = ROI_SCALE,
    threshold: float = 0.5,
):
    h, w = gray.shape[:2]
    m1 = predict_full(stage1, gray, size, device, threshold)
    bbox = largest_bbox(m1)

    if bbox is None:
        side = int(round(min(h, w) * 0.60))
        cx, cy = w//2, h//2
        roi = (
            max(0, cx-side//2), max(0, cy-side//2),
            min(w, cx+side//2), min(h, cy+side//2)
        )
    else:
        roi = square_roi_from_bbox(bbox, h, w, scale=roi_scale)

    x1, y1, x2, y2 = roi
    crop = gray[y1:y2, x1:x2]
    prob = torch.sigmoid(stage2(gray_to_tensor(crop, size, device)).float())[0, 0].cpu().numpy()
    roi_mask = (prob > threshold).astype(np.uint8) * 255
    roi_mask = cv2.resize(roi_mask, (x2-x1, y2-y1), interpolation=cv2.INTER_NEAREST)

    full = np.zeros((h, w), np.uint8)
    full[y1:y2, x1:x2] = roi_mask
    return clean_mask(full), roi, m1


def clean_mask(mask: np.ndarray) -> np.ndarray:
    b = (mask > 127).astype(np.uint8) * 255
    contours, _ = cv2.findContours(b, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not contours:
        return np.zeros_like(mask)
    cnt = max(contours, key=cv2.contourArea)
    out = np.zeros_like(mask)
    cv2.drawContours(out, [cnt], -1, 255, -1)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
    out = cv2.morphologyEx(out, cv2.MORPH_CLOSE, k)
    return out


# ---------------------------------------------------------------------
# V3 geometry: robust four-side line fitting
# ---------------------------------------------------------------------
def _order_clockwise(points: np.ndarray) -> np.ndarray:
    points = np.asarray(points, np.float32)
    c = points.mean(axis=0)
    a = np.arctan2(points[:,1]-c[1], points[:,0]-c[0])
    return points[np.argsort(a)]


def _four_corner_polygon(cnt):
    hull = cv2.convexHull(cnt)
    peri = cv2.arcLength(hull, True)
    for ratio in np.linspace(0.005, 0.12, 100):
        approx = cv2.approxPolyDP(hull, ratio * peri, True)
        if len(approx) == 4:
            return _order_clockwise(approx.reshape(4,2).astype(np.float32))
    return None


def _point_line_distance(pts, a, b):
    pts = np.asarray(pts, np.float32)
    a = np.asarray(a, np.float32)
    b = np.asarray(b, np.float32)
    v = b-a
    length = float(np.linalg.norm(v))
    if length < 1e-6:
        return np.full(len(pts), 9999.0, np.float32)
    return np.abs(v[0]*(a[1]-pts[:,1]) - (a[0]-pts[:,0])*v[1]) / length


def _side_points(contour_points, a, b, tolerance):
    pts = contour_points.astype(np.float32)
    a, b = np.asarray(a,np.float32), np.asarray(b,np.float32)
    v = b-a
    vv = float(np.dot(v,v))
    if vv < 1e-6:
        return None
    dist = _point_line_distance(pts,a,b)
    t = ((pts-a) @ v) / vv
    keep = (dist < tolerance) & (t > -0.15) & (t < 1.15)
    sel = pts[keep]
    return sel if len(sel) >= 5 else None


def _fit_line(points):
    pts = np.asarray(points,np.float32).reshape(-1,1,2)
    line = cv2.fitLine(pts, cv2.DIST_HUBER, 0, 0.01, 0.01).reshape(-1)
    p = np.array([float(line[2]),float(line[3])],np.float64)
    d = np.array([float(line[0]),float(line[1])],np.float64)
    return p,d


def _line_intersection(p1,d1,p2,d2):
    A = np.array([[d1[0],-d2[0]],[d1[1],-d2[1]]],np.float64)
    b = np.asarray(p2,np.float64)-np.asarray(p1,np.float64)
    if abs(float(np.linalg.det(A))) < 1e-8:
        return None
    t = np.linalg.solve(A,b)[0]
    return np.asarray(p1,np.float64)+t*np.asarray(d1,np.float64)


def extreme_vertices(mask: np.ndarray):
    b = clean_mask(mask)
    contours,_ = cv2.findContours(b,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    if not contours:
        return None
    cnt=max(contours,key=cv2.contourArea)
    pts=cnt.reshape(-1,2)
    if len(pts)<4:
        return None
    return {
        "N": tuple(map(float,pts[np.argmin(pts[:,1])])),
        "E": tuple(map(float,pts[np.argmax(pts[:,0])])),
        "S": tuple(map(float,pts[np.argmax(pts[:,1])])),
        "W": tuple(map(float,pts[np.argmin(pts[:,0])])),
    }


def v3_vertices(mask: np.ndarray):
    b=clean_mask(mask)
    contours,_=cv2.findContours(b,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
    if not contours:
        return None
    cnt=max(contours,key=cv2.contourArea)
    fallback=extreme_vertices(b)
    if cv2.contourArea(cnt)<20:
        return fallback

    pts=cnt.reshape(-1,2).astype(np.float32)
    rough=_four_corner_polygon(cnt)
    if rough is None:
        return fallback

    x,y,w,h=cv2.boundingRect(cnt)
    tolerance=max(3.0,max(w,h)*0.08)
    lines=[]
    for i in range(4):
        sel=_side_points(pts,rough[i],rough[(i+1)%4],tolerance)
        if sel is None:
            return fallback
        lines.append(_fit_line(sel))

    corners=[]
    for i in range(4):
        c=_line_intersection(lines[(i-1)%4][0],lines[(i-1)%4][1],lines[i][0],lines[i][1])
        if c is None or not np.all(np.isfinite(c)):
            return fallback
        corners.append(c)
    corners=np.asarray(corners,np.float32)

    N=corners[np.argmin(corners[:,1])]
    E=corners[np.argmax(corners[:,0])]
    S=corners[np.argmax(corners[:,1])]
    W=corners[np.argmin(corners[:,0])]
    return {"N":tuple(map(float,N)),"E":tuple(map(float,E)),
            "S":tuple(map(float,S)),"W":tuple(map(float,W))}


# ---------------------------------------------------------------------
# Hybrid: V3 direction + V5-style Scharr edge endpoint snap
# ---------------------------------------------------------------------
def _edge_mag(gray: np.ndarray) -> np.ndarray:
    """
    원본 grayscale의 Scharr gradient magnitude.
    99.5 percentile로 정규화해 강한 outlier의 영향을 제한한다.
    """
    g = enhance_gray(gray)
    gx = cv2.Scharr(g, cv2.CV_32F, 1, 0)
    gy = cv2.Scharr(g, cv2.CV_32F, 0, 1)
    mag = cv2.magnitude(gx, gy)
    q = float(np.percentile(mag, 99.5)) + 1e-6
    return np.clip(mag / q, 0.0, 2.0).astype(np.float32)


def _bilinear(img: np.ndarray, x: float, y: float) -> float:
    """float 좌표에서 bilinear sampling."""
    h, w = img.shape[:2]
    if x < 0.0 or y < 0.0 or x > w - 1 or y > h - 1:
        return 0.0

    x0 = int(np.floor(x))
    y0 = int(np.floor(y))
    x1 = min(x0 + 1, w - 1)
    y1 = min(y0 + 1, h - 1)

    ax = x - x0
    ay = y - y0

    return float(
        (1.0 - ay) * ((1.0 - ax) * img[y0, x0] + ax * img[y0, x1])
        + ay * ((1.0 - ax) * img[y1, x0] + ax * img[y1, x1])
    )


def _ray_limit(center: np.ndarray, u: np.ndarray, h: int, w: int) -> float:
    """center에서 u 방향으로 이미지 경계까지 갈 수 있는 최대 거리."""
    vals = []

    if u[0] > 1e-9:
        vals.append((w - 1 - center[0]) / u[0])
    elif u[0] < -1e-9:
        vals.append((0 - center[0]) / u[0])

    if u[1] > 1e-9:
        vals.append((h - 1 - center[1]) / u[1])
    elif u[1] < -1e-9:
        vals.append((0 - center[1]) / u[1])

    vals = [float(v) for v in vals if v >= 0]
    return min(vals) if vals else 0.0


def _mask_endpoint_on_ray(
    mask: np.ndarray,
    center: np.ndarray,
    u: np.ndarray,
    rough_distance: float,
    step: float = 0.25,
) -> float | None:
    """
    핵심 변경점:
    원본 edge가 아니라 Stage2 binary mask가 '길이'를 결정한다.

    center에서 대각선 방향 u로 이동하면서 mask foreground가 끝나는
    inside -> outside 경계를 찾는다.

    반환값은 center로부터의 거리 t이며, 0.25 px 간격 탐색 +
    binary mask의 bilinear 0.5 crossing 보간을 사용한다.
    """
    h, w = mask.shape[:2]
    m = (mask > 127).astype(np.float32)

    max_to_border = _ray_limit(center, u, h, w)
    if max_to_border <= 1.0:
        return None

    # V3 rough point보다 충분히 바깥까지 확인하되,
    # 이미지 전체의 잡음까지 검색하지 않는다.
    tmax = min(max_to_border - 0.25, max(rough_distance * 1.55, rough_distance + 18.0))
    if tmax <= 1.0:
        return None

    ts = np.arange(0.0, tmax + step, step, dtype=np.float32)
    vals = np.empty(len(ts), dtype=np.float32)

    for i, t in enumerate(ts):
        p = center + u * float(t)
        vals[i] = _bilinear(m, float(p[0]), float(p[1]))

    inside = vals >= 0.5

    # center가 아주 미세하게 mask 밖이면 첫 foreground 구간부터 추적.
    inside_indices = np.flatnonzero(inside)
    if len(inside_indices) == 0:
        return None

    # 중심에 가장 가까운 foreground에서 시작한다.
    start_i = int(inside_indices[0])

    # foreground에 진입한 뒤 처음으로 확실하게 background가 되는 경계를 찾는다.
    # 2 samples 연속 background를 요구해 작은 1-sample hole에 덜 민감하게 한다.
    crossing_i = None
    for i in range(max(start_i + 1, 1), len(ts) - 1):
        if inside[i - 1] and (not inside[i]) and (not inside[i + 1]):
            crossing_i = i
            break

    if crossing_i is None:
        # fallback: 마지막 foreground 위치
        last_i = int(inside_indices[-1])
        if last_i >= len(ts) - 1:
            return float(ts[last_i])
        crossing_i = last_i + 1

    i0 = max(0, crossing_i - 1)
    i1 = crossing_i

    t0 = float(ts[i0])
    t1 = float(ts[i1])
    v0 = float(vals[i0])
    v1 = float(vals[i1])

    # bilinear mask 값이 0.5를 통과하는 subpixel 위치를 1차 보간.
    if abs(v1 - v0) > 1e-6:
        alpha = (0.5 - v0) / (v1 - v0)
        alpha = float(np.clip(alpha, 0.0, 1.0))
        return t0 + alpha * (t1 - t0)

    return 0.5 * (t0 + t1)


def _edge_profile_value(
    gray_edge: np.ndarray,
    center: np.ndarray,
    u: np.ndarray,
    perp: np.ndarray,
    t: float,
) -> float:
    """
    대각선 ray 한 점의 edge 강도.
    정확한 선 한 픽셀만 보지 않고 수직 ±1 px도 확인해서
    약간의 line-fitting 오차에 견디게 한다.
    """
    p = center + u * float(t)
    vals = [
        _bilinear(gray_edge, float((p + perp * s)[0]), float((p + perp * s)[1]))
        for s in (-1.0, 0.0, 1.0)
    ]
    return float(max(vals))


def _parabolic_peak_offset(y_minus: float, y0: float, y_plus: float) -> float:
    """
    3점 포물선 보간.
    반환값은 중심 sample 기준 [-0.5, +0.5] 범위의 subpixel offset.
    """
    denom = y_minus - 2.0 * y0 + y_plus
    if abs(denom) < 1e-8:
        return 0.0

    delta = 0.5 * (y_minus - y_plus) / denom
    return float(np.clip(delta, -0.5, 0.5))


def _subpixel_edge_refine(
    gray_edge: np.ndarray,
    center: np.ndarray,
    u: np.ndarray,
    mask_t: float,
    radius: float = 4.0,
    sample_step: float = 0.5,
) -> float:
    """
    mask endpoint 주변 ±4 px에서만 원본 Scharr edge를 사용한다.

    중요한 안전장치:
    - 먼지/스크래치/검은 점이 아무리 강해도 ±4 px 밖이면 후보가 아님.
    - mask endpoint가 기본 위치이며, edge는 '미세 보정'만 담당.
    - 최종 peak는 포물선 보간으로 subpixel화한다.
    """
    perp = np.array([-u[1], u[0]], dtype=np.float32)

    offsets = np.arange(-radius, radius + sample_step * 0.5, sample_step, dtype=np.float32)
    raw = np.array(
        [
            _edge_profile_value(gray_edge, center, u, perp, mask_t + float(d))
            for d in offsets
        ],
        dtype=np.float32,
    )

    # mask endpoint에서 멀어질수록 부드럽게 감점.
    # edge가 약할 경우 엉뚱한 ±4 px 끝점으로 튀는 것을 방지.
    sigma = 2.0
    prior = np.exp(-0.5 * (offsets / sigma) ** 2).astype(np.float32)
    score = raw * (0.72 + 0.28 * prior)

    j = int(np.argmax(score))
    best_offset = float(offsets[j])

    # 인접 sample을 이용한 subpixel 포물선 보간.
    if 0 < j < len(offsets) - 1:
        frac = _parabolic_peak_offset(
            float(score[j - 1]),
            float(score[j]),
            float(score[j + 1]),
        )
        best_offset += frac * sample_step

    # edge 보정량은 절대 ±4 px 밖으로 나가지 못함.
    best_offset = float(np.clip(best_offset, -radius, radius))
    return float(mask_t + best_offset)


def _snap_ray_mask_subpixel(
    mask: np.ndarray,
    center: np.ndarray,
    rough_pt: np.ndarray,
    gray_edge: np.ndarray,
    edge_radius: float = 4.0,
) -> np.ndarray:
    """
    V6.1 endpoint:
    1) V3 rough point -> 방향만 사용
    2) Stage2 mask ray crossing -> 기본 길이
    3) 그 주변 ±4 px Scharr -> local refinement
    4) 포물선 보간 -> subpixel endpoint
    """
    v = rough_pt - center
    t0 = float(np.linalg.norm(v))
    if t0 < 5.0:
        return rough_pt.astype(np.float32)

    u = v / t0

    mask_t = _mask_endpoint_on_ray(mask, center, u, t0)
    if mask_t is None or not np.isfinite(mask_t):
        # mask ray 실패 시 V3 결과 그대로 사용.
        return rough_pt.astype(np.float32)

    refined_t = _subpixel_edge_refine(
        gray_edge,
        center,
        u,
        mask_t,
        radius=edge_radius,
        sample_step=0.5,
    )

    p = center + u * refined_t
    return p.astype(np.float32)


def hybrid_vertices(mask: np.ndarray, gray: np.ndarray):
    """
    V6.1 Hybrid geometry

    방향:
        V3 robust four-side line fitting

    길이:
        Stage2 segmentation mask의 ray boundary

    미세 위치:
        mask boundary 주변 ±4 px의 원본 Scharr edge +
        3-point parabolic subpixel interpolation

    따라서 먼 곳의 강한 먼지/스크래치 edge로 endpoint가 날아가는
    기존 V6 문제를 막는다.
    """
    clean = clean_mask(mask)
    rough = v3_vertices(clean)
    if rough is None:
        return None

    pts = {k: np.asarray(rough[k], np.float32) for k in CORNERS}
    center = np.mean(np.stack(list(pts.values())), axis=0)
    edge = _edge_mag(gray)

    out = {}
    for k in CORNERS:
        p = _snap_ray_mask_subpixel(
            clean,
            center,
            pts[k],
            edge,
            edge_radius=4.0,
        )
        out[k] = (float(p[0]), float(p[1]))

    return out


def diagonals_px(verts: dict[str,Vertex]) -> tuple[float,float,float]:
    d1=float(np.hypot(verts["S"][0]-verts["N"][0],verts["S"][1]-verts["N"][1]))
    d2=float(np.hypot(verts["E"][0]-verts["W"][0],verts["E"][1]-verts["W"][1]))
    return d1,d2,0.5*(d1+d2)


def vertex_mean_error(pred, gt) -> float | None:
    if pred is None or gt is None:
        return None
    vals=[]
    for k in CORNERS:
        vals.append(float(np.hypot(pred[k][0]-gt[k][0],pred[k][1]-gt[k][1])))
    return float(np.mean(vals))


def direction_error_deg(pred, gt) -> float | None:
    if pred is None or gt is None:
        return None

    def vec(v,a,b):
        x=np.array([v[b][0]-v[a][0],v[b][1]-v[a][1]],np.float64)
        n=np.linalg.norm(x)
        return x/max(n,1e-9)

    errs=[]
    for a,b in (("N","S"),("W","E")):
        u=vec(pred,a,b); v=vec(gt,a,b)
        c=float(np.clip(abs(np.dot(u,v)),-1,1))
        errs.append(np.degrees(np.arccos(c)))
    return float(np.mean(errs))


def overlay_mask(gray,mask,color=(46,204,113)):
    vis=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
    tint=np.zeros_like(vis); tint[:]=color
    a=(mask>127).astype(np.float32)*0.45
    out=vis.astype(np.float32)*(1-a[...,None])+tint.astype(np.float32)*a[...,None]
    return np.clip(out,0,255).astype(np.uint8)


def draw_geometry(gray,verts,color=(0,70,255)):
    vis=cv2.cvtColor(gray,cv2.COLOR_GRAY2BGR)
    if verts is None:
        return vis
    pts={k:(int(round(verts[k][0])),int(round(verts[k][1]))) for k in CORNERS}
    cv2.line(vis,pts["N"],pts["S"],color,2,cv2.LINE_AA)
    cv2.line(vis,pts["W"],pts["E"],color,2,cv2.LINE_AA)
    for k,p in pts.items():
        cv2.circle(vis,p,7,color,-1,cv2.LINE_AA)
        cv2.putText(vis,k,(p[0]+8,p[1]-8),cv2.FONT_HERSHEY_SIMPLEX,0.7,color,2)
    d1,d2,dm=diagonals_px(verts)
    cv2.putText(vis,f"d1={d1:.1f} d2={d2:.1f} mean={dm:.1f}",
                (16,vis.shape[0]-18),cv2.FONT_HERSHEY_SIMPLEX,0.65,color,2)
    return vis


# ---------------------------------------------------------------------
# single-file bundle
# ---------------------------------------------------------------------
def save_bundle(path: Path, stage1: nn.Module, stage2: nn.Module, size: int, meta: dict):
    blob={
        "arch":ARCH,
        "size":size,
        "roi_scale":ROI_SCALE,
        "stage1_model":{k:v.detach().cpu() for k,v in stage1.state_dict().items()},
        "stage2_model":{k:v.detach().cpu() for k,v in stage2.state_dict().items()},
        **meta,
    }
    torch.save(blob,path)


def load_bundle(path: Path, device: torch.device):
    blob=torch.load(path,map_location=device,weights_only=False)
    s1=ResNet34UNet(pretrained=False).to(device)
    s2=ResNet34UNet(pretrained=False).to(device)
    s1.load_state_dict(blob["stage1_model"])
    s2.load_state_dict(blob["stage2_model"])
    s1.eval(); s2.eval()
    return s1,s2,int(blob.get("size",DEFAULT_SIZE)),blob
