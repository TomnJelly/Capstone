V6 Hybrid

권장 폴더:
C:\Capstone\
  v6\
    common.py
    train.py
    kaggle_cell.py
    preview.py
    upload.py
  weights\
    best_v6_hybrid.pt
  Vicker_Database\

아이디어:
1. Stage1 ResNet34 -> ROI
2. Stage2 ResNet34 -> ROI 정밀 segmentation
3. V3 line fitting -> 중심 + 대각선 방향
4. 그 방향을 고정하고 Scharr edge + mask boundary로 N/E/S/W 끝점 snap
5. d1/d2/mean 계산

Kaggle:
- kaggle_cell.py 전체를 새 셀에 복붙
- 실행 완료 후:
  /kaggle/working/best_v6_hybrid.pt
  /kaggle/working/metrics_v6_hybrid.json

PC:
best_v6_hybrid.pt를 C:\Capstone\weights\ 에 넣고

cd C:\Capstone\v6
python preview.py --split II --samples 10

단일 이미지:
python upload.py "C:\경로\사진.png"


[이번 버전 변경]
- Early Stopping 완전 제거
- Stage1: epochs1 만큼 끝까지 학습
- Stage2: epochs2 만큼 끝까지 학습
- 각 Stage에서 val Dice 최고 모델은 메모리에 보관 후 최종 사용
