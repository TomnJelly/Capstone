V6.1 Hybrid - Mask Ray + Local Subpixel Edge

핵심 수정:
1. V3 line fitting은 대각선 '방향'만 담당
2. Stage2 segmentation mask에서 중심 -> 방향 ray를 쏴서
   foreground가 끝나는 지점을 기본 endpoint로 결정
3. 원본 Scharr edge는 그 endpoint 주변 ±4 px에서만 사용
4. 3-point parabolic interpolation으로 subpixel endpoint 계산

기존 V6 문제:
- 0.72*t0 ~ 1.38*t0 전체에서 가장 강한 edge를 찾았기 때문에
  검은 먼지/스크래치/반사 edge로 꼭짓점이 멀리 날아갈 수 있었음.

V6.1:
- 길이는 mask가 결정
- edge는 ±4 px 미세보정만
- 따라서 먼 외란으로 jump할 수 없음

중요:
모델 구조(Stage1/Stage2 ResNet34)는 바뀌지 않았습니다.
따라서 기존 best_v6_hybrid.pt로도 V6.1 후처리를 바로 시험할 수 있습니다.
새로 학습하면 best_v6_1_hybrid.pt가 생성됩니다.

Kaggle:
kaggle_cell.py 전체를 셀 하나에 복붙해서 실행.
Early stopping 없음.
Stage1 35 epoch + Stage2 35 epoch.

PC 권장:
C:\Capstone\
  v6_1\
  weights\
    best_v6_1_hybrid.pt  (새 학습)
    또는 best_v6_hybrid.pt (기존 weight도 테스트 가능)
  Vicker_Database\
