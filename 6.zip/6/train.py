#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""V6 Hybrid training: DB-I + DB-II, Stage1 full + Stage2 ROI, one checkpoint."""

from __future__ import annotations
import argparse, json, sys
from pathlib import Path

import cv2
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader, ConcatDataset

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))

from common import (
    ARCH, DEFAULT_SIZE, ROI_SCALE, ResNet34UNet,
    find_data_root, db_dirs, list_ids, split_70_30,
    load_gray, load_mask, enhance_gray, gt_roi_from_mask,
    predict_roi, hybrid_vertices, v3_vertices, diagonals_px,
    save_bundle
)


def aug_pair(image,mask):
    if np.random.rand()<0.5:
        image,mask=cv2.flip(image,1),cv2.flip(mask,1)
    if np.random.rand()<0.5:
        image,mask=cv2.flip(image,0),cv2.flip(mask,0)
    k=int(np.random.randint(0,4))
    if k:
        image,mask=np.rot90(image,k).copy(),np.rot90(mask,k).copy()
    if np.random.rand()<0.5:
        a=float(np.random.uniform(-12,12))
        h,w=image.shape[:2]
        M=cv2.getRotationMatrix2D((w/2,h/2),a,1)
        image=cv2.warpAffine(image,M,(w,h),flags=cv2.INTER_LINEAR,borderMode=cv2.BORDER_REFLECT_101)
        mask=cv2.warpAffine(mask,M,(w,h),flags=cv2.INTER_NEAREST,borderMode=cv2.BORDER_CONSTANT,borderValue=0)
    alpha=float(np.random.uniform(0.72,1.28))
    beta=int(np.random.randint(-22,23))
    image=np.clip(image.astype(np.float32)*alpha+beta,0,255).astype(np.uint8)
    if np.random.rand()<0.25:
        image=cv2.GaussianBlur(image,(3,3),0.6)
    if np.random.rand()<0.35:
        noise=np.random.normal(0,6,image.shape).astype(np.float32)
        image=np.clip(image.astype(np.float32)+noise,0,255).astype(np.uint8)
    return image,mask


def to_tensor(gray,size):
    x=cv2.resize(enhance_gray(gray),(size,size),interpolation=cv2.INTER_AREA)
    x=x.astype(np.float32)/255.0
    rgb=np.stack([x,x,x],axis=0)
    return torch.from_numpy(rgb)


def mask_tensor(mask,size):
    y=cv2.resize(mask,(size,size),interpolation=cv2.INTER_NEAREST)
    return torch.from_numpy((y>127).astype(np.float32)).unsqueeze(0)


class FullDataset(Dataset):
    def __init__(self,root,db,ids,size,augment):
        self.root=root; self.db=db; self.ids=list(ids); self.size=size; self.augment=augment
        self.img_dir,self.mask_dir=db_dirs(root,db)
    def __len__(self): return len(self.ids)
    def __getitem__(self,i):
        stem=self.ids[i]
        img=load_gray(self.img_dir/f"{stem}.png")
        mask=load_mask(self.mask_dir/f"{stem}.png")
        if self.augment: img,mask=aug_pair(img,mask)
        return {"image":to_tensor(img,self.size),"mask":mask_tensor(mask,self.size),"id":f"{self.db}:{stem}"}


class RoiDataset(Dataset):
    def __init__(self,root,db,ids,size,augment):
        self.root=root; self.db=db; self.ids=list(ids); self.size=size; self.augment=augment
        self.img_dir,self.mask_dir=db_dirs(root,db)
    def __len__(self): return len(self.ids)
    def __getitem__(self,i):
        stem=self.ids[i]
        img=load_gray(self.img_dir/f"{stem}.png")
        mask=load_mask(self.mask_dir/f"{stem}.png")
        roi=gt_roi_from_mask(mask,ROI_SCALE,jitter=0.08 if self.augment else 0.0)
        x1,y1,x2,y2=roi
        img=img[y1:y2,x1:x2]
        mask=mask[y1:y2,x1:x2]
        if self.augment: img,mask=aug_pair(img,mask)
        return {"image":to_tensor(img,self.size),"mask":mask_tensor(mask,self.size),"id":f"{self.db}:{stem}"}


def loss_fn(logits,target,eps=1e-6):
    bce=torch.nn.functional.binary_cross_entropy_with_logits(logits,target)
    pred=torch.sigmoid(logits)
    num=2*(pred*target).sum(dim=(1,2,3))
    den=pred.sum(dim=(1,2,3))+target.sum(dim=(1,2,3))+eps
    dice=1-(num/den).mean()
    dil=torch.nn.functional.max_pool2d(target,3,1,1)
    ero=1-torch.nn.functional.max_pool2d(1-target,3,1,1)
    edge=(dil-ero).clamp(0,1)
    per=torch.nn.functional.binary_cross_entropy_with_logits(logits,target,reduction="none")
    edge_bce=(per*edge).sum()/edge.sum().clamp_min(1)
    return bce+dice+0.5*edge_bce


@torch.no_grad()
def val_seg(model,loader,device):
    model.eval(); vals=[]
    for b in loader:
        x=b["image"].to(device); y=b["mask"].to(device)
        p=(torch.sigmoid(model(x).float())>0.5)
        g=y>0.5
        inter=(p&g).sum(dim=(1,2,3)).float()
        den=p.sum(dim=(1,2,3)).float()+g.sum(dim=(1,2,3)).float()
        vals.extend((2*inter/den.clamp_min(1)).cpu().tolist())
    return float(np.mean(vals)) if vals else 0.0


def train_model(model,train_loader,val_loader,device,epochs,lr,label):
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    use_amp=device.type=="cuda"
    scaler=torch.amp.GradScaler("cuda",enabled=use_amp)
    best=-1; best_state=None
    for ep in range(1,epochs+1):
        model.train(); total=0; n=0
        for b in train_loader:
            x=b["image"].to(device); y=b["mask"].to(device)
            opt.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda",enabled=use_amp):
                loss=loss_fn(model(x),y)
            scaler.scale(loss).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
            scaler.step(opt); scaler.update()
            total+=float(loss.item())*x.size(0); n+=x.size(0)
        vd=val_seg(model,val_loader,device)
        mark=""
        if vd>best:
            best=vd
            best_state={k:v.detach().cpu().clone() for k,v in model.state_dict().items()}
            mark=" <- best"
        print(f"{label} epoch {ep:03d}/{epochs} loss={total/max(n,1):.4f} val_dice={vd:.4f}{mark}",flush=True)
    if best_state:
        model.load_state_dict(best_state)
    return best


@torch.no_grad()
def final_report(stage1,stage2,data,val_map,size,device):
    rows=[]
    for db,ids in val_map.items():
        img_dir,mask_dir=db_dirs(data,db)
        for stem in ids:
            gray=load_gray(img_dir/f"{stem}.png")
            gt=load_mask(mask_dir/f"{stem}.png")
            pred,roi,_=predict_roi(stage1,stage2,gray,size,device)
            pv=hybrid_vertices(pred,gray)
            gv=hybrid_vertices(gt,gray)
            if pv is None or gv is None: continue
            pd1,pd2,pm=diagonals_px(pv)
            gd1,gd2,gm=diagonals_px(gv)
            rows.append({
                "db":db,"id":stem,
                "mean_err":abs(pm-gm)/gm if gm>1 else None,
                "d1_err":abs(pd1-gd1)/gd1 if gd1>1 else None,
                "d2_err":abs(pd2-gd2)/gd2 if gd2>1 else None,
            })
    e=[r["mean_err"] for r in rows if r["mean_err"] is not None]
    d1=[r["d1_err"] for r in rows if r["d1_err"] is not None]
    d2=[r["d2_err"] for r in rows if r["d2_err"] is not None]
    return {
        "n":len(rows),
        "mean_diag_error":float(np.mean(e)) if e else None,
        "median_diag_error":float(np.median(e)) if e else None,
        "mean_d1_error":float(np.mean(d1)) if d1 else None,
        "mean_d2_error":float(np.mean(d2)) if d2 else None,
        "rows":rows,
    }


def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument("--data",type=Path,default=None)
    p.add_argument("--out",type=Path,default=ROOT.parent/"weights")
    p.add_argument("--size",type=int,default=DEFAULT_SIZE)
    p.add_argument("--epochs1",type=int,default=35)
    p.add_argument("--epochs2",type=int,default=35)
    p.add_argument("--batch",type=int,default=6)
    p.add_argument("--lr",type=float,default=2e-4)
    p.add_argument("--seed",type=int,default=42)
    p.add_argument("--workers",type=int,default=2)
    return p.parse_args()


def main():
    args=parse_args()
    np.random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(args.seed)
    data=find_data_root(args.data)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    args.out.mkdir(parents=True,exist_ok=True)
    print("data =",data); print("device =",device)

    train_map={}; val_map={}
    for db in ("I","II"):
        tr,va=split_70_30(list_ids(data,db),args.seed)
        train_map[db]=tr; val_map[db]=va
        print(f"DB-{db}: train={len(tr)} val={len(va)}")

    train_full=ConcatDataset([FullDataset(data,db,train_map[db],args.size,True) for db in ("I","II")])
    val_full=ConcatDataset([FullDataset(data,db,val_map[db],args.size,False) for db in ("I","II")])
    train_roi=ConcatDataset([RoiDataset(data,db,train_map[db],args.size,True) for db in ("I","II")])
    val_roi=ConcatDataset([RoiDataset(data,db,val_map[db],args.size,False) for db in ("I","II")])

    kw=dict(batch_size=args.batch,num_workers=args.workers,pin_memory=device.type=="cuda")
    ltr1=DataLoader(train_full,shuffle=True,**kw); lva1=DataLoader(val_full,shuffle=False,**kw)
    ltr2=DataLoader(train_roi,shuffle=True,**kw); lva2=DataLoader(val_roi,shuffle=False,**kw)

    print("\n=== Stage1 full-image training ===")
    s1=ResNet34UNet(pretrained=True).to(device)
    best1=train_model(s1,ltr1,lva1,device,args.epochs1,args.lr,"S1")

    print("\n=== Stage2 ROI training ===")
    s2=ResNet34UNet(pretrained=True).to(device)
    best2=train_model(s2,ltr2,lva2,device,args.epochs2,args.lr,"S2")

    out=args.out/"best_v6_1_hybrid.pt"
    report=final_report(s1,s2,data,val_map,args.size,device)
    meta={
        "stage1_val_dice":best1,
        "stage2_val_dice":best2,
        "seed":args.seed,
        "train_n":sum(map(len,train_map.values())),
        "val_n":sum(map(len,val_map.values())),
        "final_mean_diag_error":report["mean_diag_error"],
        "final_median_diag_error":report["median_diag_error"],
    }
    save_bundle(out,s1,s2,args.size,meta)

    (args.out/"metrics_v6_1_hybrid.json").write_text(
        json.dumps(report,ensure_ascii=False,indent=2),encoding="utf-8"
    )
    print("\n=== FINAL HYBRID ===")
    if report["mean_diag_error"] is not None:
        print(f"mean={100*report['mean_diag_error']:.3f}% median={100*report['median_diag_error']:.3f}%")
        print(f"d1={100*report['mean_d1_error']:.3f}% d2={100*report['mean_d2_error']:.3f}%")
    print("saved:",out)


if __name__=="__main__":
    main()
