#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V6.1 Hybrid Subpixel 업로드 사이트.

- 사진 업로드
- Stage1 -> ROI
- Stage2 segmentation
- V3 방향 + mask ray endpoint + local Scharr subpixel
- d1 / d2 / mean 표시

가중치 검색 순서:
1) C:\Capstone\weights\best_v6_1_hybrid.pt
2) C:\Capstone\weights\best_v6_hybrid.pt
3) 현재 v6_1 폴더의 weights\...
"""

from __future__ import annotations

import argparse
import base64
import http.server
import json
import re
import socketserver
import sys
import threading
import time
import webbrowser
from pathlib import Path

import cv2
import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from common import (  # noqa: E402
    load_bundle,
    predict_roi,
    hybrid_vertices,
    diagonals_px,
    overlay_mask,
    draw_geometry,
)

MAX_BYTES = 25 * 1024 * 1024
ALLOWED_EXT = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="V6.1 upload inference site")
    p.add_argument("--ckpt", type=Path, default=None, help="best_v6_1_hybrid.pt 또는 best_v6_hybrid.pt")
    p.add_argument("--port", type=int, default=8767)
    p.add_argument("--no-open", action="store_true")
    return p.parse_args()


def find_ckpt(explicit: Path | None) -> Path:
    if explicit is not None:
        p = explicit.expanduser().resolve()
        if not p.exists():
            raise FileNotFoundError(f"가중치 파일이 없습니다: {p}")
        return p

    candidates = [
        ROOT.parent / "weights" / "best_v6_1_hybrid.pt",
        ROOT.parent / "weights" / "best_v6_hybrid.pt",
        ROOT / "weights" / "best_v6_1_hybrid.pt",
        ROOT / "weights" / "best_v6_hybrid.pt",
    ]

    for p in candidates:
        if p.exists() and p.stat().st_size > 1024:
            return p

    tried = "\n".join(f" - {p}" for p in candidates)
    raise FileNotFoundError(
        "V6/V6.1 가중치를 찾지 못했습니다.\n"
        "다음 위치 중 하나에 파일을 두세요:\n"
        f"{tried}\n\n"
        "예: C:\\Capstone\\weights\\best_v6_hybrid.pt"
    )


def png_data_url(img: np.ndarray) -> str:
    ok, buf = cv2.imencode(".png", img)
    if not ok:
        raise RuntimeError("PNG 인코딩 실패")
    return "data:image/png;base64," + base64.b64encode(buf.tobytes()).decode("ascii")


def decode_gray(raw: bytes) -> np.ndarray:
    arr = np.frombuffer(raw, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise ValueError("이미지를 읽지 못했습니다. PNG/JPG 파일인지 확인하세요.")
    return img


def draw_roi(gray: np.ndarray, roi) -> np.ndarray:
    vis = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
    if roi is None:
        return vis
    x1, y1, x2, y2 = [int(v) for v in roi]
    cv2.rectangle(vis, (x1, y1), (x2 - 1, y2 - 1), (0, 200, 255), 2, cv2.LINE_AA)
    return vis


def _header_map(blob: bytes) -> dict[str, str]:
    text = blob.decode("utf-8", "replace")
    out: dict[str, str] = {}
    for line in text.split("\r\n"):
        if ":" not in line:
            continue
        key, val = line.split(":", 1)
        out[key.strip().lower()] = val.strip()
    return out


def _disp_name(disp: str) -> tuple[str | None, str | None]:
    name = None
    filename = None

    m = re.search(r'name="([^"]*)"', disp)
    if m:
        name = m.group(1)

    star = re.search(r"filename\*=(?:UTF-8|utf-8)''([^;]+)", disp)
    if star:
        from urllib.parse import unquote
        filename = unquote(star.group(1))
    else:
        m = re.search(r'filename="([^"]*)"', disp)
        if m:
            filename = m.group(1)
        else:
            m = re.search(r"filename=([^;]+)", disp)
            if m:
                filename = m.group(1).strip()

    return name, filename


def parse_multipart(content_type: str, body: bytes) -> tuple[dict[str, str], list[tuple[str, bytes]]]:
    if "boundary=" not in content_type:
        raise ValueError("multipart boundary 없음")

    boundary = content_type.split("boundary=", 1)[1].strip().strip('"').encode("ascii", "ignore")
    marker = b"--" + boundary

    fields: dict[str, str] = {}
    files: list[tuple[str, bytes]] = []

    for chunk in body.split(marker):
        if not chunk or chunk in (b"--", b"--\r\n"):
            continue
        if chunk.startswith(b"--"):
            continue
        if chunk.startswith(b"\r\n"):
            chunk = chunk[2:]
        if chunk.endswith(b"\r\n"):
            chunk = chunk[:-2]

        split_at = chunk.find(b"\r\n\r\n")
        if split_at < 0:
            continue

        headers = _header_map(chunk[:split_at])
        data = chunk[split_at + 4 :]
        disp = headers.get("content-disposition", "")
        name, filename = _disp_name(disp)

        if not name:
            continue

        if filename is not None:
            files.append((filename, data))
        else:
            fields[name] = data.decode("utf-8", "replace")

    return fields, files


PAGE = r"""<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>V6.1 비커스 예측</title>
  <style>
    :root { --bg:#0e1117; --card:#171b22; --line:#2a3140; --text:#e8edf5; --muted:#9aa6b8; --accent:#3b82f6; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:"Segoe UI",sans-serif; background:var(--bg); color:var(--text); }
    header { padding:14px 20px 12px; border-bottom:1px solid var(--line); }
    h1 { margin:0 0 6px; font-size:24px; }
    .sub { color:var(--muted); font-size:15px; }
    .row { display:flex; gap:10px; align-items:center; margin-top:12px; }
    .drop {
      border:1px dashed #3d4a63; border-radius:12px; padding:18px 16px;
      flex:1; background:#12161d; color:var(--muted); cursor:pointer; text-align:center;
    }
    .drop.over { border-color:var(--accent); color:var(--text); }
    button {
      background:var(--accent); color:white; border:1px solid #2563eb;
      border-radius:8px; padding:10px 16px; font-size:15px; cursor:pointer; font-weight:600;
    }
    button:disabled { opacity:.5; cursor:wait; }
    .err { color:#f87171; margin-top:10px; min-height:1.2em; white-space:pre-wrap; }
    .layout { display:grid; grid-template-columns:260px 1fr; min-height:calc(100vh - 170px); }
    nav { border-right:1px solid var(--line); padding:12px; overflow:auto; }
    nav button.item {
      display:flex; width:100%; align-items:center; justify-content:space-between; gap:8px;
      background:transparent; color:var(--text); border:1px solid transparent; border-radius:8px;
      padding:10px 12px; margin-bottom:6px; cursor:pointer; font-size:14px; text-align:left;
    }
    nav button.item.active { background:#1f2a3d; border-color:var(--accent); }
    main { padding:14px 18px 28px; }
    .now { margin:0 0 12px; font-size:18px; color:var(--muted); }
    .now b { color:var(--text); }
    .grid { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; }
    .stage { background:var(--card); border:1px solid var(--line); border-radius:12px; padding:10px; }
    .stage h2 { margin:0 0 8px; font-size:16px; }
    .stage img { width:100%; background:#000; border-radius:8px; display:block; cursor:zoom-in; }
    .zoom {
      position:fixed; inset:0; display:none; align-items:center; justify-content:center;
      flex-direction:column; gap:10px; background:rgba(0,0,0,.88); z-index:80;
      padding:20px; cursor:zoom-out;
    }
    .zoom.on { display:flex; }
    .zoom img { max-width:96vw; max-height:calc(100vh - 72px); object-fit:contain; border-radius:8px; }
    .zoom .cap { font-size:16px; }
    .empty { color:var(--muted); padding:40px 8px; }
    @media (max-width:1200px) { .grid { grid-template-columns:1fr 1fr; } }
    @media (max-width:800px) {
      .layout { grid-template-columns:1fr; }
      .grid { grid-template-columns:1fr; }
    }
  </style>
</head>
<body>
<header>
  <h1>V6.1 비커스 예측</h1>
  <div class="sub">V3 방향 + Stage2 mask 길이 + ±4px Scharr subpixel 보정</div>
  <div class="row">
    <div class="drop" id="drop">
      <span id="droptext">사진을 끌어오거나 클릭해서 고르세요</span>
      <input id="files" type="file" accept="image/png,image/jpeg,image/bmp,image/tiff,image/webp" multiple hidden />
    </div>
    <button id="run" type="button">예측</button>
  </div>
  <div class="err" id="err"></div>
</header>

<div class="layout">
  <nav id="thumbs"><div class="empty">아직 올린 사진이 없습니다.</div></nav>
  <main>
    <div class="now" id="now"></div>
    <div class="grid" id="stages"></div>
  </main>
</div>

<div class="zoom" id="zoom">
  <div class="cap" id="zoomcap"></div>
  <img id="zoomimg" alt="" />
</div>

<script>
const filesEl = document.getElementById("files");
const drop = document.getElementById("drop");
const dropText = document.getElementById("droptext");
const runBtn = document.getElementById("run");
const errEl = document.getElementById("err");

let picked = [];
let items = [];
let idx = 0;

const zoomEl = document.getElementById("zoom");
const zoomImg = document.getElementById("zoomimg");
const zoomCap = document.getElementById("zoomcap");

function closeZoom() { zoomEl.classList.remove("on"); }
function toggleZoom(src, title) {
  zoomEl.classList.add("on");
  zoomImg.src = src;
  zoomCap.textContent = title + " · 클릭하면 닫힘";
}
zoomEl.onclick = closeZoom;
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeZoom(); });

function setErr(msg) { errEl.textContent = msg || ""; }

function setPicked(list) {
  picked = [...list].filter((f) =>
    f && (((f.type || "").startsWith("image/")) || /\.(png|jpe?g|bmp|tiff?|webp)$/i.test(f.name))
  );
  dropText.textContent = picked.length
    ? picked.length + "장 선택됨 · 다시 고르려면 클릭"
    : "사진을 끌어오거나 클릭해서 고르세요";
}

drop.onclick = () => filesEl.click();
drop.ondragover = (e) => { e.preventDefault(); drop.classList.add("over"); };
drop.ondragleave = () => drop.classList.remove("over");
drop.ondrop = (e) => {
  e.preventDefault();
  drop.classList.remove("over");
  setPicked(e.dataTransfer.files);
};
filesEl.onchange = () => setPicked(filesEl.files);

function render() {
  const nav = document.getElementById("thumbs");
  const now = document.getElementById("now");
  const box = document.getElementById("stages");

  if (!items.length) {
    nav.innerHTML = '<div class="empty">아직 올린 사진이 없습니다.</div>';
    now.textContent = "";
    box.innerHTML = "";
    return;
  }

  nav.innerHTML = "";
  items.forEach((it, i) => {
    const b = document.createElement("button");
    b.type = "button";
    b.className = "item" + (i === idx ? " active" : "");
    const mean = it.mean == null ? "—" : it.mean.toFixed(2) + "px";
    b.innerHTML = `<span>${it.name}</span><span>${mean}</span>`;
    b.onclick = () => { idx = i; render(); };
    nav.appendChild(b);
  });

  const it = items[idx];
  const d1 = it.d1 == null ? "—" : it.d1.toFixed(2);
  const d2 = it.d2 == null ? "—" : it.d2.toFixed(2);
  const mean = it.mean == null ? "—" : it.mean.toFixed(2);

  now.innerHTML =
    `<b>${it.name}</b> · d1 <b>${d1}px</b> · d2 <b>${d2}px</b> · 평균 <b>${mean}px</b>` +
    `<br><span style="font-size:14px">${it.model}</span>`;

  const stages = [
    ["입력 이미지", it.input],
    ["Stage1 ROI", it.roi],
    ["Stage2 예측 마스크", it.mask],
    ["V6.1 예측 기하", it.geom],
  ];

  box.innerHTML = "";
  stages.forEach(([title, src]) => {
    const el = document.createElement("section");
    el.className = "stage";
    el.innerHTML = `<h2>${title}</h2><img src="${src}" alt="${title}" />`;
    el.querySelector("img").onclick = () => toggleZoom(src, title);
    box.appendChild(el);
  });
}

runBtn.onclick = async () => {
  if (!picked.length) {
    setErr("사진을 먼저 고르세요.");
    return;
  }

  setErr("");
  runBtn.disabled = true;
  items = [];
  idx = 0;
  render();

  try {
    for (let i = 0; i < picked.length; i++) {
      runBtn.textContent = `예측 중… ${i + 1}/${picked.length}`;

      const form = new FormData();
      form.append("file", picked[i]);

      const res = await fetch("/predict", {
        method: "POST",
        body: form
      });

      const data = await res.json();

      if (!res.ok || !data.ok) {
        throw new Error(data.error || ("HTTP " + res.status));
      }

      items.push(data);
      idx = items.length - 1;
      render();
    }
  } catch (e) {
    setErr(String(e.message || e));
  } finally {
    runBtn.disabled = false;
    runBtn.textContent = "예측";
  }
};

render();
</script>
</body>
</html>
"""


class Predictor:
    def __init__(self, ckpt: Path) -> None:
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.lock = threading.Lock()
        self.ckpt = ckpt

        print(f"loading: {ckpt}", flush=True)
        print(f"device : {self.device}", flush=True)

        self.stage1, self.stage2, self.size, self.meta = load_bundle(
            self.ckpt,
            self.device,
        )

        print(
            f"loaded: arch={self.meta.get('arch')} size={self.size}",
            flush=True,
        )

    def run(self, raw: bytes, filename: str) -> dict:
        ext = Path(filename).suffix.lower()
        if ext and ext not in ALLOWED_EXT:
            raise ValueError(f"지원하지 않는 확장자입니다: {ext}")

        gray = decode_gray(raw)

        with self.lock, torch.inference_mode():
            pred, roi, _stage1_mask = predict_roi(
                self.stage1,
                self.stage2,
                gray,
                self.size,
                self.device,
            )

        verts = hybrid_vertices(pred, gray)

        d1 = d2 = mean = None
        if verts is not None:
            d1, d2, mean = diagonals_px(verts)

        mask_vis = overlay_mask(gray, pred, (180, 90, 220))
        roi_vis = draw_roi(gray, roi)
        geom_vis = draw_geometry(gray, verts, (0, 165, 255))

        return {
            "ok": True,
            "name": Path(filename).name or "upload",
            "model": (
                f"V6.1 Hybrid · {self.meta.get('arch', 'ResNet34 ROI')} · "
                f"size={self.size} · {self.ckpt.name}"
            ),
            "d1": d1,
            "d2": d2,
            "mean": mean,
            "verts": {
                k: [float(v[0]), float(v[1])]
                for k, v in (verts or {}).items()
            },
            "input": png_data_url(gray),
            "roi": png_data_url(roi_vis),
            "mask": png_data_url(mask_vis),
            "geom": png_data_url(geom_vis),
        }


def make_handler(predictor: Predictor):
    class Handler(http.server.BaseHTTPRequestHandler):
        def log_message(self, format: str, *args) -> None:
            return

        def _send(self, code: int, body: bytes, content_type: str) -> None:
            self.send_response(code)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self) -> None:
            path = self.path.split("?", 1)[0]
            if path in ("/", "/index.html"):
                self._send(200, PAGE.encode("utf-8"), "text/html; charset=utf-8")
                return
            self._send(404, b"not found", "text/plain; charset=utf-8")

        def do_POST(self) -> None:
            if self.path.split("?", 1)[0] != "/predict":
                self._send(
                    404,
                    b'{"ok":false,"error":"not found"}',
                    "application/json; charset=utf-8",
                )
                return

            try:
                length = int(self.headers.get("Content-Length") or "0")

                if length <= 0:
                    raise ValueError("업로드된 데이터가 없습니다.")
                if length > MAX_BYTES:
                    raise ValueError("파일이 너무 큽니다. 최대 25MB입니다.")

                body = self.rfile.read(length)
                _fields, files = parse_multipart(
                    self.headers.get("Content-Type") or "",
                    body,
                )

                if not files:
                    raise ValueError("업로드된 이미지 파일이 없습니다.")

                filename, raw = files[0]
                payload = predictor.run(raw, filename)

                data = json.dumps(
                    payload,
                    ensure_ascii=False,
                ).encode("utf-8")

                self._send(
                    200,
                    data,
                    "application/json; charset=utf-8",
                )

            except Exception as exc:
                import traceback
                traceback.print_exc()

                data = json.dumps(
                    {
                        "ok": False,
                        "error": f"{type(exc).__name__}: {exc}",
                    },
                    ensure_ascii=False,
                ).encode("utf-8")

                self._send(
                    400,
                    data,
                    "application/json; charset=utf-8",
                )

    return Handler


def serve(port: int, handler_cls, open_browser: bool) -> None:
    class Server(socketserver.ThreadingTCPServer):
        allow_reuse_address = True
        daemon_threads = True

    httpd = None
    bound = port

    for candidate in range(port, port + 15):
        try:
            httpd = Server(("127.0.0.1", candidate), handler_cls)
            bound = candidate
            break
        except OSError:
            continue

    if httpd is None:
        raise SystemExit("사용 가능한 포트를 열 수 없습니다.")

    url = f"http://127.0.0.1:{bound}/"

    print("", flush=True)
    print(f"업로드 예측 사이트: {url}", flush=True)
    print("브라우저가 자동으로 안 열리면 위 주소를 직접 입력하세요.", flush=True)
    print("종료: Ctrl+C", flush=True)

    thread = threading.Thread(
        target=httpd.serve_forever,
        daemon=True,
    )
    thread.start()

    time.sleep(0.3)

    if open_browser:
        webbrowser.open(url, new=2)

    try:
        while thread.is_alive():
            thread.join(timeout=0.5)
    except KeyboardInterrupt:
        print("\n업로드 사이트 종료", flush=True)
        httpd.shutdown()


def main() -> None:
    args = parse_args()

    try:
        ckpt = find_ckpt(args.ckpt)
        predictor = Predictor(ckpt)
    except Exception as exc:
        print("", flush=True)
        print("=" * 60, flush=True)
        print("시작 실패", flush=True)
        print(f"{type(exc).__name__}: {exc}", flush=True)
        print("=" * 60, flush=True)
        raise

    serve(
        args.port,
        make_handler(predictor),
        open_browser=not args.no_open,
    )


if __name__ == "__main__":
    main()
